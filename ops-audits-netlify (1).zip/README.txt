
Ops Audits — Netlify Package
============================

Files:
  - index.html      -> your app entry point
  - 404.html        -> friendly fallback (if a deep link fails)
  - netlify.toml    -> config (publish root, headers, and SPA-style fallback)

How to deploy on Netlify:
  1) Go to https://app.netlify.com/drop
  2) Drag-and-drop the entire ZIP file you downloaded from ChatGPT.
  3) When it finishes, open the generated site URL.

Notes:
  * The redirects rule in netlify.toml ensures iPhone Safari deep linking always lands back on index.html.
  * If you later add subfolders/assets, just upload new files to the same site by dragging a fresh ZIP.
